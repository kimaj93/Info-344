﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebRole1
{
    public class Entity : TableEntity
    {
        public Entity(String key, String value)
        {
            this.PartitionKey = key;
            this.RowKey = value;
        }

        public Entity() { }
    }
}