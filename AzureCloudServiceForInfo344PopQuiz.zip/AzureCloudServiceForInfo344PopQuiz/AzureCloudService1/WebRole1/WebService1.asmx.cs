﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebRole1
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        [WebMethod]
        public void deleteQ()
        {
            CloudQueue q = initializeQ();
            q.DeleteIfExists();
        }

        public CloudQueue initializeQ()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudQueueClient qClient = storageAccount.CreateCloudQueueClient();
            CloudQueue q = qClient.GetQueueReference("numq");
            q.CreateIfNotExists();
            return q;
        }

        [WebMethod]
        public void deleteTable()
        {
            CloudTable table = initializeTable();
            table.DeleteIfExists();
        }

        public CloudTable initializeTable()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                ConfigurationManager.AppSettings["StorageConnectionString"]);
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();
            CloudTable table = tableClient.GetTableReference("sumtable");
            table.CreateIfNotExists();
            return table;
        }

        [WebMethod]
        public void workerRoleCalculateSum(int one, int two, int three)
        {
            CloudQueue q = initializeQ();
            CloudQueueMessage message = new CloudQueueMessage(one.ToString() + " " + two.ToString() + " " + three.ToString());
            q.AddMessage(message);
        }
        
        [WebMethod]
        public String readSumFromTableStorage()
        {
            CloudTable table = initializeTable();
            TableQuery<Entity> rangeQuery = new TableQuery<Entity>().
                Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "sums"));
            String s = "";
            List<String> l = new List<String>();
            foreach (Entity e in table.ExecuteQuery(rangeQuery))
            {
                s = e.RowKey;
                l.Add(e.RowKey);
            }
            return "Current sum: " + s + " All of them: " + String.Join(", ", l.ToArray());
        }
        
    }
}
