﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FilterText
{
    class Program 
    {
        static void Main(string[] args)
        {
            // Filtering text for only alphabetical characters and underscores.
            /*string regex = "^[a-zA-Z_]+$";
            Regex rx = new Regex(regex);
            using (StreamReader sr = new StreamReader(@"C:\enwiki-20141208-all-titles-in-ns0")) {
                using (StreamWriter sw = new StreamWriter(@"C:\output.txt")) { 
                    while (sr.EndOfStream == false) {
                        string line = sr.ReadLine();
                        if (rx.IsMatch(line)) {
                            sw.WriteLine(line);
                        }
                    }
                }
            }*/

            // Testing ASCII values.
            /*char c = 'A';
            string s = ((int)c).ToString();
            Console.WriteLine(s);
            Console.ReadLine();*/
            
            ArrayList l = new ArrayList();
            using (StreamReader sr = new StreamReader(@"C:\output.txt"))
            {
                for (int i = 0; i < 10; i++)
                {
                    String line = sr.ReadLine();
                    l.Add(line);
                }
            }
            ListVocabulary lv = new ListVocabulary(l);

            Console.WriteLine(lv.isPrefix("AAA"));
            Console.WriteLine(lv.add("A"));
            Console.ReadLine();
        }
    }
}
