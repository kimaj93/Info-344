﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Collections;

namespace FilterText
{
    public interface Vocabulary
    {
        Boolean add(String word);
        Boolean isPrefix(String prefix);
        Boolean contains(String word);
    }

    public class ListVocabulary : Vocabulary
    {
        private ArrayList words = new ArrayList();

        // Constructor adds all words to this list, and sorts it.
        public ListVocabulary(ArrayList words)
        {
            foreach (String word in words)
            {
                this.words.Add(word);
            }
            this.words.Sort();
        }


        // Adds tbe word to this list if it doesn't already exist and returns true.
        // Else returns false.
        public Boolean add(String word)
        {
            int position = this.words.BinarySearch(word);
            // Position < 0 means that word is not this list.
            if (position < 0)
            {
                words.Insert(-(position + 1), word);
                return true;
            }
            return false;
        }

        // Returns true if the prefix is a prefix of another word in this list.
        public Boolean isPrefix(String prefix)
        {
            prefix = prefix.ToLower();
            int position = this.words.BinarySearch(prefix);
            if (position >= 0)
            {
                // The prefix is a word in this list.
                // Check the following word if there is one 
                // because words longer than the prefix are needed.
                if (position + 1 < words.Count)
                {
                    String nextWord = words[position + 1].ToString().ToLower();
                    return nextWord[0].ToString().ToLower() == prefix;
                }
            }
            position = -(position + 1);
            // The prefix is not a word in this list. (-1 or less.)
            // Check what index it should be added at.
            // If the next word starts with the prefix, then return true.
            if (position >= words.Count)
            {
                // position == words.Count means that there is no other word to check. 
                return false;
            }
            String nWord = words[position].ToString().ToLower();
            return nWord[0].ToString().ToLower() == prefix;
        }

        // Returns true if this list contains the given word.
        public Boolean contains(String word)
        {
            // Less than 0 means that this list doesn't have the word.
            int position = this.words.BinarySearch(word);
            return position >= 0;
        }
    }
}