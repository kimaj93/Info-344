﻿function display() {
    var obj = { name: $("#name").val() };
    $.ajax({
        type: "POST",
        url: "WebService1.asmx/suggest",
        data: JSON.stringify(obj),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(msg) {
            $("#results").html(msg.d);
        },
        error: function(msg) {
            alert(JSON.stringify(msg));
        }
    });
};

